import java.util.Scanner;

public class IsItEven {
	
	
	//	Given a number, return true if it's even and false otherwise.
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		
		// code to solve the problem.  You can write and call other methods as well.
		
		System.out.println();                     // print your answer and just your answer.

	}

}
