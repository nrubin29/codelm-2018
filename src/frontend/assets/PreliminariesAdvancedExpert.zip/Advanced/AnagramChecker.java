import java.util.Scanner;

public class AnagramChecker {
    /*
     * You are writing a program to determine whether two words are anagrams of each other. Two words are anagrams of each other if they contain the same number of each character.

	Input
	Two strings, a and b, containing lowercase letters a-z and possibly spaces.

	Output
	true if a and b are anagrams of each other and false if not.
     */
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String a = s.next();
		String b = s.next();
		
		// code to solve the problem.  You can write and call other methods as well.
		
	}

}
