import java.util.Scanner;

public class GoldbachConjecture {
	/* The Goldbach Conjecture states that any even number greater than two can be expressed as a sum of two prime numbers.

	Input
	An integer, n, which is even and greater than 2.

	Output
	Any one combination of two prime numbers that add to the given number. The result should be a string formatted as “a + b” 
	with exactly the right amount of whitespace where a and b are the two numbers.
	 */
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();

		// code to solve the problem.  You can write and call other methods as well.

		System.out.println();                     // print your answer and just your answer.
	}

}
