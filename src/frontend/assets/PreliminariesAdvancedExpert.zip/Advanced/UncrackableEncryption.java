import java.util.Scanner;

public class UncrackableEncryption {

	/*You are writing a program to validate numbers as specified below.

	Input
	An integer of 6 digits, n, to be validated.

	Output
	true if no more than 2 digits are greater than the average of all of the digits and false if not.
	 */

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();

		// code to solve the problem.  You can write and call other methods as well.

		System.out.println();                     // print your answer and just your answer.

	}

}
