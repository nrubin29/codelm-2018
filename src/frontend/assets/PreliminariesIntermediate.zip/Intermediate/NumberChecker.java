import java.util.Scanner;

public class NumberChecker {
	
	static Scanner s = new Scanner(System.in);
    // The International Standard Book Number (ISBN) is a 13-digit code for identifying books.  Write a program to compute 
	// the 1-3-sum of a 13-digit number, and print YES if the 13-digit number is valid ISBN and NO otherwise. 
	// Do not print anything else or your solution will be marked wrong.
	
	//	When you are finished, copy and paste the the entire contents of this file into the employee
	//	dashboard to test your algorithm.
	public static void main(String[] args) {
		
		int serialNumber = s.nextInt();			  // The last three digits of the serial number
		
		// code to solve the problem.  You can write and call other methods as well.
		
	}

}
