import java.util.Scanner;

public class PrettyRectangle {

	/*You are writing a program to print out a nice looking rectangle.

	Input
	An integer, n, representing the size of the rectangle; that is, the result of your program will be an n x n rectangle. n will be between 1 and 25 inclusive.

	Output
	A rectangle with a border of dashes (-) and an interior of exclamation points (!). There should be no whitespace, and each line should be followed by exactly one newline.

	You may not use more than 5 if/else if/else/switch statements. Don’t cheat.*/
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		
	}

}
